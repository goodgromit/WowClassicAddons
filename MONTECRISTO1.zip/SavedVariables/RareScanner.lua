
RareScannerDB = nil
