
diminfo = {
["Sort"] = 5,
["AutoCollect"] = false,
["AutoRepair"] = true,
["AutoSell"] = true,
}
