
SYNDICATOR_CONFIG = {
["show_inventory_tooltips"] = true,
["debug"] = false,
["show_tooltips_on_shift"] = false,
["show_currency_tooltips"] = true,
["show_equipped_items_in_tooltips"] = true,
["tooltips_connected_realms_only_2"] = true,
["show_character_race_icons"] = true,
["tooltips_character_limit"] = 2,
["show_blank_line_before_inventory"] = false,
["tooltips_faction_only"] = false,
["tooltips_sort_by_name"] = false,
["debug_timers"] = false,
["show_total_line_after_characters"] = false,
["auction_value_source"] = "none",
["show_guild_banks_in_tooltips"] = true,
["no_auction_value_source"] = false,
}
SYNDICATOR_DATA = {
["Characters"] = {
["그로밋-펜구스의흉포"] = {
["containerInfo"] = {
["bags"] = {
{
["itemCount"] = 1,
["itemID"] = 1725,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:1725::::::::12::::::::::|h[큰 배낭]|h|r",
["iconTexture"] = 133632,
},
{
["itemCount"] = 1,
["itemID"] = 1725,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:1725::::::::12::::::::::|h[큰 배낭]|h|r",
["iconTexture"] = 133632,
},
{
["itemCount"] = 1,
["itemID"] = 1725,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:1725::::::::12::::::::::|h[큰 배낭]|h|r",
["iconTexture"] = 133632,
},
{
["itemCount"] = 1,
["itemID"] = 1725,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:1725::::::::12::::::::::|h[큰 배낭]|h|r",
["iconTexture"] = 133632,
},
},
["bank"] = {
{
["itemCount"] = 1,
["itemID"] = 4496,
["isBound"] = false,
["iconTexture"] = 133634,
["itemLink"] = "|cffffffff|Hitem:4496::::::::10::::::::::|h[작은 갈색 가방]|h|r",
["quality"] = 1,
},
{
},
{
},
{
},
{
},
{
},
{
},
},
},
["bankTabs"] = {
},
["details"] = {
["class"] = 1,
["realmNormalized"] = "펜구스의흉포",
["show"] = {
["inventory"] = true,
["gold"] = true,
},
["race"] = "Tauren",
["faction"] = "Horde",
["sex"] = 2,
["className"] = "WARRIOR",
["character"] = "그로밋",
["realm"] = "펜구스의 흉포",
},
["bags"] = {
{
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
{
{
},
{
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 6462,
["isBound"] = true,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:6462::::::::12::::::::::|h[단단히 잠긴 상자]|h|r",
["iconTexture"] = 132761,
},
{
["itemCount"] = 1,
["itemID"] = 6145,
["isBound"] = true,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:6145::::::::12::::::::::|h[클라리스의 펜던트]|h|r",
["iconTexture"] = 133288,
},
{
},
{
["itemCount"] = 2,
["itemID"] = 2589,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2589::::::::12::::::::::|h[리넨 옷감]|h|r",
["iconTexture"] = 132889,
},
{
["itemCount"] = 1,
["itemID"] = 4854,
["isBound"] = true,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4854::::::::12::::::::::|h[악마의 흔적이 남은 망토]|h|r",
["iconTexture"] = 134358,
},
{
["itemCount"] = 2,
["itemID"] = 3239,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:3239::::::::12::::::::::|h[가벼운 무게추]|h|r",
["iconTexture"] = 135255,
},
{
["itemCount"] = 10,
["itemID"] = 2862,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2862::::::::12::::::::::|h[조잡한 숫돌]|h|r",
["iconTexture"] = 135248,
},
{
["itemCount"] = 10,
["itemID"] = 17056,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:17056::::::::12::::::::::|h[가벼운 깃털]|h|r",
["iconTexture"] = 132917,
},
},
{
{
["itemCount"] = 1,
["itemID"] = 4561,
["isBound"] = true,
["hasLoot"] = false,
["quality"] = 2,
["itemLink"] = "|cff1eff00|Hitem:4561::::::14:1184110208:12::::::::::|h[민첩성의 무두질용 토마호크]|h|r",
["iconTexture"] = 132410,
},
{
},
{
["itemCount"] = 5,
["itemID"] = 2318,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2318::::::::12::::::::::|h[얇은 가죽]|h|r",
["iconTexture"] = 134252,
},
{
["itemCount"] = 11,
["itemID"] = 2581,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2581::::::::12::::::::::|h[두꺼운 리넨 붕대]|h|r",
["iconTexture"] = 133688,
},
{
},
{
},
{
},
{
["itemCount"] = 2,
["itemID"] = 818,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 2,
["itemLink"] = "|cff1eff00|Hitem:818::::::::12::::::::::|h[호안석]|h|r",
["iconTexture"] = 134118,
},
{
},
{
["itemCount"] = 4,
["itemID"] = 159,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:159::::::::12::::::::::|h[맑은 샘물]|h|r",
["iconTexture"] = 132794,
},
{
["itemCount"] = 11,
["itemID"] = 2840,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2840::::::::12::::::::::|h[구리 주괴]|h|r",
["iconTexture"] = 133216,
},
{
["itemCount"] = 20,
["itemID"] = 2840,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2840::::::::12::::::::::|h[구리 주괴]|h|r",
["iconTexture"] = 133216,
},
},
{
{
["itemCount"] = 16,
["itemID"] = 1251,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:1251::::::::12::::::::::|h[리넨 붕대]|h|r",
["iconTexture"] = 133685,
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 4496,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4496::::::::12::::::::::|h[작은 갈색 가방]|h|r",
["iconTexture"] = 133634,
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
["itemCount"] = 5,
["itemID"] = 118,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:118::::::::12::::::::::|h[최하급 치유 물약]|h|r",
["iconTexture"] = 134829,
},
},
{
{
["itemCount"] = 1,
["itemID"] = 6948,
["isBound"] = true,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:6948::::::::12::::::::::|h[귀환석]|h|r",
["iconTexture"] = 134414,
},
{
["itemCount"] = 1,
["itemID"] = 12989,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 3,
["itemLink"] = "|cff0070dd|Hitem:12989::::::::12::::::::::|h[가고일의 이빨]|h|r",
["iconTexture"] = 135128,
},
{
["itemCount"] = 1,
["itemID"] = 12985,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 3,
["itemLink"] = "|cff0070dd|Hitem:12985::::::::12::::::::::|h[방어의 반지]|h|r",
["iconTexture"] = 133370,
},
{
["itemCount"] = 1,
["itemID"] = 6256,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:6256::::::::12::::::::::|h[낚싯대]|h|r",
["iconTexture"] = 132932,
},
{
["itemCount"] = 1,
["itemID"] = 5956,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:5956::::::::12::::::::::|h[대장장이 망치]|h|r",
["iconTexture"] = 133057,
},
{
["itemCount"] = 1,
["itemID"] = 2901,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2901::::::::12::::::::::|h[채광용 곡괭이]|h|r",
["iconTexture"] = 134708,
},
{
["itemCount"] = 3,
["itemID"] = 6888,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:6888::::::::12::::::::::|h[알 약초구이]|h|r",
["iconTexture"] = 132834,
},
{
["itemCount"] = 20,
["itemID"] = 2680,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2680::::::::12::::::::::|h[늑대 양념 구이]|h|r",
["iconTexture"] = 134021,
},
{
["itemCount"] = 189,
["itemID"] = 2516,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2516::::::::12::::::::::|h[소형 탄환]|h|r",
["iconTexture"] = 132384,
},
{
["itemCount"] = 25,
["itemID"] = 4960,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4960::::::::12::::::::::|h[섬광 탄환]|h|r",
["iconTexture"] = 132384,
},
{
},
{
["itemCount"] = 12,
["itemID"] = 2680,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2680::::::::12::::::::::|h[늑대 양념 구이]|h|r",
["iconTexture"] = 134021,
},
},
{
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
},
["auctions"] = {
{
["itemCount"] = 10,
["itemID"] = 2862,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2862::::::::12::::::::::|h[조잡한 숫돌]|h|r",
["iconTexture"] = 135248,
},
},
["currencyByHeader"] = {
{
["name"] = "알 수 없음",
["currencies"] = {
},
},
},
["money"] = 87316,
["mail"] = {
},
["void"] = {
},
["currencies"] = {
},
["equipped"] = {
{
},
{
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 6125,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:6125::::::::12::::::::::|h[수습투사용 멜빵]|h|r",
["iconTexture"] = 132719,
},
{
["itemCount"] = 1,
["itemID"] = 4968,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4968::::::::12::::::::::|h[끈으로 엮은 멜빵]|h|r",
["iconTexture"] = 132719,
},
{
["itemCount"] = 1,
["itemID"] = 4913,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4913::::::::12::::::::::|h[채색한 사슬 허리띠]|h|r",
["iconTexture"] = 132495,
},
{
["itemCount"] = 1,
["itemID"] = 4909,
["isBound"] = true,
["quality"] = 2,
["itemLink"] = "|cff1eff00|Hitem:4909::::::::12::::::::::|h[코도 사냥꾼 다리보호구]|h|r",
["iconTexture"] = 134582,
},
{
["itemCount"] = 1,
["itemID"] = 4972,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4972::::::::12::::::::::|h[절벽 등산용 장화]|h|r",
["iconTexture"] = 132535,
},
{
["itemCount"] = 1,
["itemID"] = 4969,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4969::::::::12::::::::::|h[강화된 손목보호구]|h|r",
["iconTexture"] = 132602,
},
{
["itemCount"] = 1,
["itemID"] = 4910,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4910::::::::12::::::::::|h[채색한 사슬 장갑]|h|r",
["iconTexture"] = 132938,
},
{
},
{
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 4668,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4668::::::::12::::::::::|h[전투 사슬 망토]|h|r",
["iconTexture"] = 133771,
},
{
["itemCount"] = 1,
["itemID"] = 4964,
["isBound"] = true,
["quality"] = 2,
["itemLink"] = "|cff1eff00|Hitem:4964::::::::12::::::::::|h[고블린 분쇄기]|h|r",
["iconTexture"] = 133052,
},
{
},
{
["itemCount"] = 1,
["itemID"] = 3079,
["isBound"] = true,
["quality"] = 2,
["itemLink"] = "|cff1eff00|Hitem:3079::::::::12::::::::::|h[스코른의 라이플]|h|r",
["iconTexture"] = 135610,
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
["bank"] = {
{
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
{
{
},
{
},
{
},
{
},
{
},
{
},
},
{
},
{
},
{
},
{
},
{
},
{
},
},
},
["그로밋-진행서버PvP"] = {
["containerInfo"] = {
["bags"] = {
{
["itemCount"] = 1,
["itemID"] = 1725,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:1725::::::::9::::::::::|h[큰 배낭]|h|r",
["iconTexture"] = 133632,
},
{
["itemCount"] = 1,
["itemID"] = 1725,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:1725::::::::9::::::::::|h[큰 배낭]|h|r",
["iconTexture"] = 133632,
},
{
["itemCount"] = 1,
["itemID"] = 1725,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:1725::::::::9::::::::::|h[큰 배낭]|h|r",
["iconTexture"] = 133632,
},
{
["itemCount"] = 1,
["itemID"] = 1725,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:1725::::::::9::::::::::|h[큰 배낭]|h|r",
["iconTexture"] = 133632,
},
},
["bank"] = {
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
},
["bankTabs"] = {
},
["details"] = {
["class"] = 1,
["realmNormalized"] = "진행서버PvP",
["show"] = {
["inventory"] = true,
["gold"] = true,
},
["race"] = "Tauren",
["faction"] = "Horde",
["sex"] = 2,
["character"] = "그로밋",
["className"] = "WARRIOR",
["realm"] = "진행 서버 PvP",
},
["bags"] = {
{
{
["itemCount"] = 1,
["itemID"] = 6948,
["isBound"] = true,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:6948::::::::9::::::::::|h[귀환석]|h|r",
["iconTexture"] = 134414,
},
{
["itemCount"] = 1,
["itemID"] = 6256,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:6256::::::::9::::::::::|h[낚싯대]|h|r",
["iconTexture"] = 132932,
},
{
["itemCount"] = 5,
["itemID"] = 118,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:118::::::::9::::::::::|h[최하급 치유 물약]|h|r",
["iconTexture"] = 134829,
},
{
},
{
["itemCount"] = 25,
["itemID"] = 4960,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4960::::::::9::::::::::|h[섬광 탄환]|h|r",
["iconTexture"] = 132384,
},
{
["itemCount"] = 6,
["itemID"] = 1251,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:1251::::::::9::::::::::|h[리넨 붕대]|h|r",
["iconTexture"] = 133685,
},
{
["itemCount"] = 1,
["itemID"] = 2901,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2901::::::::9::::::::::|h[채광용 곡괭이]|h|r",
["iconTexture"] = 134708,
},
{
["itemCount"] = 3,
["itemID"] = 2318,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2318::::::::9::::::::::|h[얇은 가죽]|h|r",
["iconTexture"] = 134252,
},
{
["itemCount"] = 2,
["itemID"] = 2672,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2672::::::::9::::::::::|h[질긴 늑대 고기]|h|r",
["iconTexture"] = 133970,
},
{
["itemCount"] = 6,
["itemID"] = 2680,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2680::::::::9::::::::::|h[늑대 양념 구이]|h|r",
["iconTexture"] = 134021,
},
{
["itemCount"] = 15,
["itemID"] = 2589,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2589::::::::9::::::::::|h[리넨 옷감]|h|r",
["iconTexture"] = 132889,
},
{
},
{
["itemCount"] = 199,
["itemID"] = 2516,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2516::::::::9::::::::::|h[소형 탄환]|h|r",
["iconTexture"] = 132384,
},
{
},
{
["itemCount"] = 1,
["itemID"] = 5411,
["isBound"] = true,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:5411::::::::9::::::::::|h[윈터후프 정화의 토템상]|h|r",
["iconTexture"] = 135139,
},
{
["itemCount"] = 3,
["itemID"] = 2835,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2835::::::::9::::::::::|h[작은 암석]|h|r",
["iconTexture"] = 135232,
},
},
{
{
["itemCount"] = 6,
["itemID"] = 2770,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2770::::::::9::::::::::|h[구리 광석]|h|r",
["iconTexture"] = 134566,
},
{
},
{
["itemCount"] = 1,
["itemID"] = 15009,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 2,
["itemLink"] = "|cff1eff00|Hitem:15009::::::584:171716480:9::::::::::|h[원숭이의 원시 다리보호구]|h|r",
["iconTexture"] = 134585,
},
{
["itemCount"] = 4,
["itemID"] = 6889,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:6889::::::::9::::::::::|h[작은 알]|h|r",
["iconTexture"] = 132832,
},
{
},
{
},
{
["itemCount"] = 2,
["itemID"] = 4540,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4540::::::::9::::::::::|h[질긴 빵]|h|r",
["iconTexture"] = 133964,
},
{
},
{
["itemCount"] = 2,
["itemID"] = 117,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:117::::::::9::::::::::|h[질긴 쇠고기]|h|r",
["iconTexture"] = 133972,
},
{
},
{
},
{
},
},
{
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
{
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
{
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 12989,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 3,
["itemLink"] = "|cff0070dd|Hitem:12989::::::::9::::::::::|h[가고일의 이빨]|h|r",
["iconTexture"] = 135128,
},
{
["itemCount"] = 1,
["itemID"] = 12985,
["isBound"] = false,
["hasLoot"] = false,
["quality"] = 3,
["itemLink"] = "|cff0070dd|Hitem:12985::::::::9::::::::::|h[방어의 반지]|h|r",
["iconTexture"] = 133370,
},
},
{
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
},
["auctions"] = {
},
["currencyByHeader"] = {
{
["name"] = "알 수 없음",
["currencies"] = {
},
},
},
["currencies"] = {
},
["void"] = {
},
["mail"] = {
},
["money"] = 97137,
["equipped"] = {
{
},
{
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 6125,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:6125::::::::9::::::::::|h[수습투사용 멜빵]|h|r",
["iconTexture"] = 132719,
},
{
["itemCount"] = 1,
["itemID"] = 6059,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:6059::::::::9::::::::::|h[유목민의 조끼]|h|r",
["iconTexture"] = 132721,
},
{
["itemCount"] = 1,
["itemID"] = 4913,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4913::::::::9::::::::::|h[채색한 사슬 허리띠]|h|r",
["iconTexture"] = 132495,
},
{
["itemCount"] = 1,
["itemID"] = 10635,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:10635::::::::9::::::::::|h[채색한 사슬 다리보호구]|h|r",
["iconTexture"] = 134583,
},
{
["itemCount"] = 1,
["itemID"] = 4972,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4972::::::::9::::::::::|h[절벽 등산용 장화]|h|r",
["iconTexture"] = 132535,
},
{
["itemCount"] = 1,
["itemID"] = 4969,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4969::::::::9::::::::::|h[강화된 손목보호구]|h|r",
["iconTexture"] = 132602,
},
{
["itemCount"] = 1,
["itemID"] = 4910,
["isBound"] = true,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:4910::::::::9::::::::::|h[채색한 사슬 장갑]|h|r",
["iconTexture"] = 132938,
},
{
},
{
},
{
},
{
},
{
["itemCount"] = 1,
["itemID"] = 2652,
["isBound"] = false,
["quality"] = 0,
["itemLink"] = "|cff9d9d9d|Hitem:2652::::::::9::::::::::|h[허술한 사슬 망토]|h|r",
["iconTexture"] = 133754,
},
{
["itemCount"] = 1,
["itemID"] = 4561,
["isBound"] = true,
["quality"] = 2,
["itemLink"] = "|cff1eff00|Hitem:4561::::::14:1184110208:9::::::::::|h[민첩성의 무두질용 토마호크]|h|r",
["iconTexture"] = 132410,
},
{
["itemCount"] = 1,
["itemID"] = 2212,
["isBound"] = false,
["quality"] = 0,
["itemLink"] = "|cff9d9d9d|Hitem:2212::::::::9::::::::::|h[금이 간 버클러]|h|r",
["iconTexture"] = 134955,
},
{
["itemCount"] = 1,
["itemID"] = 2509,
["isBound"] = false,
["quality"] = 1,
["itemLink"] = "|cffffffff|Hitem:2509::::::::9::::::::::|h[화려한 나팔총]|h|r",
["iconTexture"] = 135611,
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
["bank"] = {
{
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
{
},
{
},
{
},
{
},
{
},
{
},
{
},
},
},
},
["Guilds"] = {
},
["Version"] = 2,
["Warband"] = {
{
["money"] = 0,
["details"] = {
["inventory"] = true,
["gold"] = true,
},
["bank"] = {
},
},
},
}
SYNDICATOR_SUMMARIES = {
["Characters"] = {
["Pending"] = {
["그로밋-펜구스의흉포"] = 1,
},
["ByRealm"] = {
["펜구스의흉포"] = {
["그로밋"] = {
["item:4910"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:12989"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:1251"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 16,
["equipped"] = 0,
["bank"] = 0,
},
["item:4668"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:1725"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 4,
["bank"] = 0,
},
["item:159"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 4,
["equipped"] = 0,
["bank"] = 0,
},
["item:2516"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 189,
["equipped"] = 0,
["bank"] = 0,
},
["item:6948"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:6125"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:12985"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:818"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 2,
["equipped"] = 0,
["bank"] = 0,
},
["item:5956"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:4964"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:2680"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 32,
["equipped"] = 0,
["bank"] = 0,
},
["item:17056"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 10,
["equipped"] = 0,
["bank"] = 0,
},
["item:2840"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 31,
["equipped"] = 0,
["bank"] = 0,
},
["item:4913"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:6256"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:4960"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 25,
["equipped"] = 0,
["bank"] = 0,
},
["item:4496"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 1,
["bank"] = 0,
},
["item:2581"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 11,
["equipped"] = 0,
["bank"] = 0,
},
["item:6888"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 3,
["equipped"] = 0,
["bank"] = 0,
},
["item:4561"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:4854"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:3079"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:118"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 5,
["equipped"] = 0,
["bank"] = 0,
},
["item:2862"] = {
["void"] = 0,
["auctions"] = 10,
["mail"] = 0,
["bags"] = 10,
["equipped"] = 0,
["bank"] = 0,
},
["item:4909"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:6145"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:4968"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:2318"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 5,
["equipped"] = 0,
["bank"] = 0,
},
["item:2901"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:6462"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:2589"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 2,
["equipped"] = 0,
["bank"] = 0,
},
["item:4969"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:4972"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:3239"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 2,
["equipped"] = 0,
["bank"] = 0,
},
},
},
["진행서버PvP"] = {
["그로밋"] = {
["item:10635"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:4910"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:2835"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 3,
["equipped"] = 0,
["bank"] = 0,
},
["item:12989"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:2212"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:4913"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:6256"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:117"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 2,
["equipped"] = 0,
["bank"] = 0,
},
["item:4960"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 25,
["equipped"] = 0,
["bank"] = 0,
},
["item:15009"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:1251"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 6,
["equipped"] = 0,
["bank"] = 0,
},
["item:2509"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:4540"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 2,
["equipped"] = 0,
["bank"] = 0,
},
["item:4972"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:1725"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 4,
["bank"] = 0,
},
["item:6059"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:118"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 5,
["equipped"] = 0,
["bank"] = 0,
},
["item:4561"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:2516"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 199,
["equipped"] = 0,
["bank"] = 0,
},
["item:5411"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:6948"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:2770"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 6,
["equipped"] = 0,
["bank"] = 0,
},
["item:6125"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:12985"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:2672"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 2,
["equipped"] = 0,
["bank"] = 0,
},
["item:6889"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 4,
["equipped"] = 0,
["bank"] = 0,
},
["item:2901"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 1,
["equipped"] = 0,
["bank"] = 0,
},
["item:2318"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 3,
["equipped"] = 0,
["bank"] = 0,
},
["item:2589"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 15,
["equipped"] = 0,
["bank"] = 0,
},
["item:4969"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
["item:2680"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 6,
["equipped"] = 0,
["bank"] = 0,
},
["item:2652"] = {
["void"] = 0,
["auctions"] = 0,
["mail"] = 0,
["bags"] = 0,
["equipped"] = 1,
["bank"] = 0,
},
},
},
},
},
["Guilds"] = {
["Pending"] = {
},
["ByRealm"] = {
},
},
["Version"] = 5,
["Warband"] = {
["Summary"] = {
{
},
},
["Pending"] = {
false,
},
},
}
