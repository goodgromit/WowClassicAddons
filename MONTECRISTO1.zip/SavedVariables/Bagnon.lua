
Bagnon_Sets = {
["latest"] = {
},
["global"] = {
["inventory"] = {
["rules"] = {
["sidebar"] = {
"all",
"normal",
"trade",
},
},
["point"] = "BOTTOMRIGHT",
["color"] = {
0,
0,
0,
0.5,
},
["reverseBags"] = false,
["y"] = 100,
["x"] = -50,
["strata"] = "MEDIUM",
["borderColor"] = {
},
["reverseSlots"] = false,
["sidebar"] = true,
["activeRules"] = {
["sidebar"] = "all",
},
["brokerObject"] = "BagnonLauncher",
},
["vault"] = {
["rules"] = {
["sidebar"] = {
"all",
"tradegoods",
"consumable",
"armor",
"questitem",
"miscellaneous",
},
},
["borderColor"] = {
},
["color"] = {
},
["activeRules"] = {
},
},
["guild"] = {
["rules"] = {
["sidebar"] = {
"all",
"tradegoods",
"consumable",
"armor",
"questitem",
"miscellaneous",
},
},
["borderColor"] = {
},
["color"] = {
},
["activeRules"] = {
},
},
["bank"] = {
["rules"] = {
["sidebar"] = {
"all",
"tradegoods",
"consumable",
"armor",
"questitem",
"miscellaneous",
},
},
["borderColor"] = {
},
["color"] = {
},
["activeRules"] = {
},
},
},
["customRules"] = {
},
["color"] = {
["quiver"] = {
},
["account"] = {
},
["enchant"] = {
},
["soul"] = {
},
["reagent"] = {
},
["mine"] = {
},
["engineer"] = {
},
["inscribe"] = {
},
["fridge"] = {
},
["gem"] = {
},
["key"] = {
},
["tackle"] = {
},
["leather"] = {
},
["normal"] = {
},
["herb"] = {
},
},
["display"] = {
},
["profiles"] = {
["진행서버PvP"] = {
},
},
}
