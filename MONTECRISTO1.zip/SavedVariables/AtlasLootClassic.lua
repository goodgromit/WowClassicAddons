
AtlasLootClassicDB = {
["global"] = {
["__addonrevision"] = 25512135,
},
["profileKeys"] = {
["그로밋 - 펜구스의 흉포"] = "그로밋 - 펜구스의 흉포",
},
["profiles"] = {
["그로밋 - 펜구스의 흉포"] = {
["minimap"] = {
["minimapPos"] = 353.9221227427568,
},
["GUI"] = {
["point"] = {
nil,
nil,
"CENTER",
0,
-3.112379636149854e-05,
},
["selectedGameVersion"] = 1,
["selected"] = {
nil,
"ScarletMonasteryGraveyard",
nil,
1,
0,
},
},
},
},
}
