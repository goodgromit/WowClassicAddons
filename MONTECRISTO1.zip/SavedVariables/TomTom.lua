
TomTomDB = {
["profileKeys"] = {
["그로밋 - 펜구스의 흉포"] = "Default",
["그로밋 - 진행 서버 PvP"] = "Default",
},
["profiles"] = {
["Default"] = {
["general"] = {
["confirmremoveall"] = false,
},
["arrow"] = {
["enablePing"] = true,
["setclosest"] = false,
["position"] = {
"TOP",
nil,
"TOP",
6.95280647277832,
-72.82967376708984,
},
["scale"] = 1.25,
},
["persistence"] = {
["savewaypoints"] = false,
["cleardistance"] = 11,
},
["block"] = {
["accuracy"] = 1,
["bordercolor"] = {
nil,
0.8000000715255737,
nil,
0,
},
["width"] = 75,
["throttle"] = 1,
["fontsize"] = 10,
["position"] = {
"TOPRIGHT",
nil,
"TOPRIGHT",
-50.08963775634766,
-166.4000091552734,
},
["height"] = 19,
["lock"] = true,
},
},
},
}
TomTomWaypoints = nil
TomTomWaypointsM = {
["profileKeys"] = {
["그로밋 - 펜구스의 흉포"] = "그로밋 - 펜구스의 흉포",
["그로밋 - 진행 서버 PvP"] = "그로밋 - 진행 서버 PvP",
},
["profiles"] = {
["그로밋 - 펜구스의 흉포"] = {
},
["그로밋 - 진행 서버 PvP"] = {
},
},
}
