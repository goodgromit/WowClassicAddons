
RangeDisplayDB3 = {
["namespaces"] = {
},
["profileKeys"] = {
["그로밋 - 펜구스의 흉포"] = "Default",
},
["profiles"] = {
["Default"] = {
["locked"] = true,
["units"] = {
["pet"] = {
},
["playertarget"] = {
["fontSize"] = 23,
["bgEnabled"] = true,
["lrSection"] = {
["enabled"] = true,
["range"] = 40,
},
["fontOutline"] = "OUTLINE",
["y"] = -212.8295593261719,
["x"] = 0.4742021560668945,
},
["focus"] = {
},
["arena2"] = {
},
["mouseover"] = {
["overLimitDisplay"] = true,
["y"] = -15.82187366485596,
["x"] = 50.87196350097656,
["checkVisible"] = false,
["lrSection"] = {
["enabled"] = true,
},
["warnEnemyOnly"] = false,
},
["arena5"] = {
},
["arena4"] = {
},
},
},
},
}
